import React from "react";
import "./activity.css";

function Activity(props) {
  return (
    <div className="box">
      <p>
        {" "}
        <img
          src={props.link}
          alt="headphones"
        />
        :{props.image}
      </p>

      <p>{props.name}</p>
      <p>R:{props.price}</p>
    </div>
  );
}
export default Activity;
