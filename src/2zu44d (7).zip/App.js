import "./styles.css";
import Students from "./student";
import Activity from "./activity";
import "./activity.css";

export default function App() {
  return (
    <div>
      <h2>image 1</h2>
      <Activity name="Headphones" price="120" />
      <Activity
        name="Headphones"
        price="120"
        link="https://images.unsplash.com/photo-1505740420928-5e560c06d30e?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2070&q=80"
      />
    </div>
  );
}
