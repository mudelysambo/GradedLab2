import React from 'react';
import Header from './Header';



function Description(props) {
  return (
    <div >
      <p>{props.Description}</p>
    </div>
  );
}
export default Description;