import React from 'react';
import Header from './Header';



function Tittle(props) {
  return (
    <div >
      <p>{props.AppTittle}</p>
    </div>
  );
}
export default Tittle;