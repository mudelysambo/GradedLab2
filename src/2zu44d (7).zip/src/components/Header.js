import React from 'react';
import Description from './Description';
import Tittle from './Tittle';


export default function Header() {
  return (
    <div >
     <Tittle AppTittle='welcome to the props setion of react'/>
     <Description Description='you are ready to take to go to the next level of react'/>
    </div>
  );
}