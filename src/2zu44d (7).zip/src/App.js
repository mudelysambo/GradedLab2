import "./styles.css";
import UserInfo from './UserInfo';
import Header from './components/Header';


export default function App() {
  return (
    <div >
     <Header />

     <UserInfo
    link="https://www.macworld.com/article/672537/apples-next-event.html"
     name="my image "
     />
    </div>
  );
}
