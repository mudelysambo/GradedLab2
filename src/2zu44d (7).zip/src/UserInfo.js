import React from "react";
import "./UserInfo.css";

function UserInfo(props) {
  return (
    <div className="picture">
      <p>
        <img
          src={props.link}
          alt="img"
        />  
      </p>
      <p>{props.name}</p>

      
    </div>
  );
}
export default UserInfo;